<div class="error">
    <p><?php echo $mensaje ?? 'Página no encontrada'; ?></p>
    <a href="/PROYECTO_BLOG/public/">Volver al inicio</a>
</div>
