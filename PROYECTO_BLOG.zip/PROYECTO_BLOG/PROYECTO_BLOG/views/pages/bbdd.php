<div class="admin-bbdd">
    <h1>Gestión de Base de Datos</h1>
    <p>Opción de gestión de BD disponible para administradores.</p>
</div>
