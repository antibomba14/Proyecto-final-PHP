<footer class="footer">
    <div class="contenedor">
        <p>&copy; <?php echo date('Y'); ?> <strong>Nexo de Ideas</strong>. Todos los derechos reservados.</p>
    </div>
</footer>
